module Lib (
 generateRandom,
 isValid,
 movesNumbers
 ) where

import System.IO
import Control.Monad
import System.Random

isValid :: FilePath -> IO (String)
isValid _ = return "ParsingError"

generateRandom :: Int -> Int -> IO (String)
generateRandom _ _ = return "Not yet implemented"

movesNumbers :: Int -> String -> IO (String)
movesNumbers _ _ = return "Not yet implemented"
