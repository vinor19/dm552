module Lib (
 generateRandom,
 isValid,
 isValidAux,
 movesNumbers
 ) where

import System.IO
import Control.Monad
import System.Random
import Data.List ((\\),sort, length, intersect)

isValidAux :: ([String],[(Integer, Integer)],[(Integer,Integer)],Integer) -> [((Integer, Integer),(Integer, Integer),String)] -> IO ()
isValidAux ((z:zs),(x:xs),(y:ys), p) [] =putStrLn (show ((z:zs),(x:xs),(y:ys), p))
isValidAux ((z:zs),[],(y:ys),0) _ =putStrLn ("(" ++ (show(z:zs)) ++ ",[],"++ (show(y:ys)) ++ ", 0)")
isValidAux ((z:zs),(x:xs),[],1) _ = putStrLn ("(" ++ (show(z:zs)) ++ "," ++ (show(x:xs)) ++ ",[]" ++ ", 1)")
isValidAux ((z:zs),(x:xs),(y:ys), p) (m:ms) = do
 if (isValidGameState ((z:zs), (x:xs), (y:ys),p))
  then do 
   let nonValid = if (p == 0) then isValidMove p m (x:xs) [(z:zs)!!0, (z:zs)!!1] else isValidMove p m (y:ys) [(z:zs)!!2, (z:zs)!!3]
   if nonValid
    then do
      (isValidAux (applyMove ((z:zs),(x:xs),(y:ys), p) m) ms)
    else do
     putStrLn("nonValid " ++ (show m))
  else do
   putStrLn("nonValid " ++ (show ((z:zs),(x:xs),(y:ys), p)))
isValid :: FilePath -> IO (String)
isValid _ = return "ParsingError"

generateRandom :: Int -> Int -> IO (String)
generateRandom _ _ = return "Not yet implemented"

movesNumbers :: Int -> String -> IO (String)
movesNumbers _ _ = return "Not yet implemented"

-- Helper functions for isValid
getPositionChange :: String -> [(Integer,Integer)]
getPositionChange "Rabbit" = [(-1,-1), (1,1), (2,0)]
getPositionChange "Cobra" = [(-1,0), (1,1), (1,-1)]
getPositionChange "Rooster" = [(-1,0), (-1,-1), (1,0), (1,1)]
getPositionChange "Tiger" = [(0,2),(0,-1)]
getPositionChange "Monkey" = [(1,1), (-1,1), (-1,-1), (1,-1)]
getPositionChange "Crab" = [(-2,0), (2, 0), (0,1)]
getPositionChange "Crane" = [(-1,-1),(0,1),(1,-1)]
getPositionChange "Frog" = [(1,-1), (-1,1), (-2,0)]
getPositionChange "Boar" = [(-1,0), (0,1), (1,0)]
getPositionChange "Horse" = [(-1,0), (0,1), (0,-1)]
getPositionChange "Elephant" = [(-1,0), (-1,1), (1,0), (1,1)]
getPositionChange "Ox" = [(1,0), (0,1), (0,-1)]
getPositionChange "Goose" = [(-1,0), (-1,1), (1,0), (1,-1)]
getPositionChange "Dragon" = [(-2,1), (-1,-1), (2,1), (1,-1)]
getPositionChange "Mantis" = [(-1,1), (0,1), (1,1)]
getPositionChange "Eel" = [(-1,1), (-1,-1), (1,0)]

newPositions _ _ [] = []
newPositions p (a,b) (x:xs)
 | p == 1 = [(a - fst x, b - snd x)] ++ newPositions p (a,b) (xs)
 | p == 0 = [(a + fst x, b + snd x)] ++ newPositions p (a,b) (xs)
 | otherwise = []

isValidGameState :: ([String],[(Integer, Integer)],[(Integer,Integer)],Integer) -> Bool
isValidGameState ((z:zs),(x:xs),(y:ys),p) = foldl (&&) True [(length (z:zs)) == 5 , (p == 1) || (p == 0) , allUnique (z:zs) , allUnique ((x:xs) ++ (y:ys)) , (0,0) <= (minimum (x:xs)) , (4,4) >= (maximum (x:xs)) , (0,0) <= (minimum (y:ys)) , (4,4) >= (maximum (y:ys)) , (z:zs) == ((z:zs) `intersect` cardList), xs == (sort xs),ys == (sort ys)]

cardList = ["Rabbit", "Cobra", "Rooster", "Tiger", "Monkey", "Crab", "Crane", "Frog", "Boar", "Horse", "Elephant", "Ox", "Goose", "Dragon", "Mantis", "Eel"]

isValidMove p ((a,b),(c,d),s) (x:xs) (y:ys) = foldl (&&) True [0<=c, c<=4, 0<=d, d<=4 , elem s (y:ys), elem (c,d) (newPositions p (a,b) ((getPositionChange s))), not (elem (c,d) (x:xs))]

updatedList :: [(Integer, Integer)] -> (Integer, Integer) -> (Integer, Integer) -> [(Integer,Integer)]
updatedList (x:xs) (a,b) (c,d) = [if y == (a,b) then (c,d) else y | y <- (x:xs)]

updateCards :: [[Char]] -> [Char] -> Integer ->  [[Char]]
updateCards z s p= do
 if p == 0
  then do
   let playerCards = [z!!0, z!!1]
   let playerCardsUpdated = sort ((playerCards\\[s]) ++ [z!!4])
   playerCardsUpdated ++ [z!!2,z!!3] ++ [s]
  else do
   let playerCards = [z!!2,z!!3]
   let playerCardsUpdated = sort((playerCards\\[s]) ++ [z!!4])
   [z!!0,z!!1] ++ playerCardsUpdated ++ [s]

applyMove :: ([String],[(Integer, Integer)],[(Integer,Integer)],Integer) -> ((Integer, Integer),(Integer, Integer),String) ->([String],[(Integer, Integer)],[(Integer,Integer)],Integer)
applyMove ((z:zs),(x:xs),(y:ys), p) ((a,b),(c,d),s) = do
 if p == 0
  then do
   if (((c,d) == y)||(c,d) == (4,2))
    then ((updateCards (z:zs) s p),(updatedList (x:xs) (a,b) (c,d)),[],1)
   else do
    let (g:gs) = (y:ys)\\[(c,d)]
    let (h:hs) = updatedList (x:xs) (a,b) (c,d)
    let k = updateCards (z:zs) s p
    (k,(h:(sort hs)),(g:(sort gs)),1)
  else do
    if (((c,d) == x)||(c,d) == (0,2))
     then ((updateCards (z:zs) s p),[],(updatedList (y:ys) (a,b) (c,d)),0)
     else do
      let (g:gs) = (x:xs)\\[(c,d)]
      let (h:hs) = updatedList (y:ys) (a,b) (c,d)
      let k = updateCards (z:zs) s p
      (k,(g:(sort gs)),(h:(sort hs)),0)

allUnique [] = True
allUnique (x:xs) = not((x `elem` xs)) && (allUnique xs)
